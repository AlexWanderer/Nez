﻿using System;
using System.Collections;
using System.Collections.Generic;


namespace Nez.LibGdxAtlases
{
	public class LibGdxAtlasFile
	{
		public List<LibGdxAtlasPage> pages = new List<LibGdxAtlasPage>();
		public List<LibGdxAtlasRegion> regions = new List<LibGdxAtlasRegion>();
	}
}

