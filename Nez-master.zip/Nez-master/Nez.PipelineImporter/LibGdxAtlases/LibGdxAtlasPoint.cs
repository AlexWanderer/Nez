﻿using System;


namespace Nez.LibGdxAtlases
{
	public class LibGdxAtlasPoint
	{
		public float x;
		public float y;


		public LibGdxAtlasPoint()
		{}


		public LibGdxAtlasPoint( float x, float y )
		{
			this.x = x;
			this.y = y;
		}
	}
}

