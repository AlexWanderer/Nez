﻿using System;


namespace Nez.LibGdxAtlases
{
	public class LibGdxAtlasProcessorResult
	{
		public LibGdxAtlasFile data;
	}
}
