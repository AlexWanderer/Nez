﻿using System;


namespace Nez.LibGdxAtlases
{
	public class LibGdxAtlasRect
	{
		public int x;
		public int y;
		public int w;
		public int h;


		public LibGdxAtlasRect()
		{}
	}
}

