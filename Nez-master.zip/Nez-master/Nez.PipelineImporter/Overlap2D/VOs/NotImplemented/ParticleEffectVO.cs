﻿using System;


namespace Nez.Overlap2D.Runtime
{
	public class ParticleEffectVO : MainItemVO
	{
		public String particleName = "";
		public float particleWidth = 100;
		public float particleHeight = 100;
	}
}

