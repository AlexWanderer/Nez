﻿using System;


namespace Nez.Overlap2D.Runtime
{
	public class Image9patchVO : MainItemVO
	{
		public String imageName = "";
		public float width = 0;
		public float height = 0;
	}
}

