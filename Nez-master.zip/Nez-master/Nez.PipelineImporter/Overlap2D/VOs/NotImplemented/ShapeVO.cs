﻿using Microsoft.Xna.Framework;


namespace Nez.Overlap2D.Runtime
{
	public class ShapeVO
	{
		public Vector2[][] polygons;
		public Circle[] circles;
	}
}

