﻿using System;


namespace Nez.Overlap2D.Runtime
{
	public class ColorPrimitiveVO : MainItemVO
	{
	}
}

