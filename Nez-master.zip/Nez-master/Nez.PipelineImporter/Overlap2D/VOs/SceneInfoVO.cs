﻿using System;
using Nez.Overlap2D.Runtime;


namespace Nez.Overlap2D.Runtime
{
	public class SceneInfoVO
	{
		public string sceneName;
		public PhysicsPropertiesVO physicsPropertiesVO;
	}
}

